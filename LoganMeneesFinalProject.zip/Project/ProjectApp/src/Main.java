// Logan Menees
// CSE 460 Final Project

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame {
    private JLabel pubUser;
    private JTextField pubUserBox;
    private JPanel MainPanel;
    private JLabel pubCuisineType;
    private JTextField pubCuisineBox;
    private JLabel mealNameLabel;
    private JTextField mealNameBox;
    private JLabel mealTimeLabel;
    private JTextField mealTimeBox;
    private JLabel mealDayLabel;
    private JTextField mealDayBox;
    private JButton publishButton;
    private JLabel subUserLabel;
    private JTextField subUserBox;
    private JLabel interestLabel;
    private JTextField interestBox;
    private JLabel dailyLabel;
    private JCheckBox dailyCheck;
    private JLabel weeklyLabel;
    private JCheckBox weeklyCheck;
    private JButton subscribeButton;
    private JTextArea resultBox;
    private JLabel frequencyLabel;
    private JTextField frequencyBox;
    private JLabel weekdayLabel;
    private JTextField weekdayBox;
    private JButton unsubscribeButton;

    public Main () {
        // initialize the gui
        setContentPane(MainPanel);
        setTitle("MealPlanner");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setVisible(true);
        MessageBroker messageBroker = new MessageBroker();
        resultBox.setText("Results will appear here\n");

        // listeners for the various buttons and the actions they perform
        publishButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // get all the information
                String mealName = mealNameBox.getText();
                String cuisineType = pubCuisineBox.getText();
                String cookTime = mealTimeBox.getText();
                // labels are a little mixed up here
                String mealType = frequencyBox.getText();
                String frequency = mealDayBox.getText();
                String weekday = weekdayBox.getText();
                Meal publishMeal = new Meal(mealName, cuisineType, cookTime, mealType, frequency, weekday);

                String username = pubUserBox.getText();

                // create a new dietitian and publish the meal
                Dietitian publisher = new Dietitian(username,messageBroker);

                if (publishMeal.mealFrequency.equals("weekly")) {
                    publisher.publishWeeklyMeal(publishMeal, publishMeal.weekday);
                } else if (publishMeal.mealFrequency.equals("daily")) {
                    publisher.publishDailyMeal(publishMeal);
                } else {
                    publisher.publishMealIdea(publishMeal);
                }
            }

        });

        subscribeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // set the customer
                String username = subUserBox.getText();
                Customer customer = new Customer(username);
                // subscribe based on meal frequency
                if (weeklyCheck.isSelected()) {
                    customer.subscribeToWeeklyMeals();
                } else if (dailyCheck.isSelected()) {
                    customer.subscribeToDailyMeals();
                } else {
                    customer.subscribeToMealIdeas();
                }

            }
        });

        // listeners to ensure that both the daily and weekly checks can't be selected
        dailyCheck.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (weeklyCheck.isSelected()) {
                    weeklyCheck.setSelected(false);
                }
            }
        });
        weeklyCheck.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (dailyCheck.isSelected()) {
                    dailyCheck.setSelected(false);
                }
            }
        });

        // listener for the unsubscribe button
        unsubscribeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = subUserBox.getText();
                Customer customer = new Customer(username);
                // set how often the meal is eaten
                String frequency;
                if (weeklyCheck.isSelected()) {
                    frequency = "weeklyMeals";
                } else if (dailyCheck.isSelected()) {
                    frequency = "dailyMeals";
                } else {
                    frequency = "mealIdeas";
                }
                customer.unsubscribeFromNotifications(frequency);
            }
        });
    }
    public static void main(String[] args) {
        new Main();
    }

    class Meal {
        // meal attributes
        String name;
        String cuisineType;
        String cookTime;
        String mealType; // breakfast, lunch, dinner
        String mealFrequency;
        String weekday;

        // constructor for meal objects
        Meal(String name, String cuisineType, String cookTime, String mealType, String mealFrequency, String weekday) {
            this.name = name;
            this.cuisineType = cuisineType;
            this.cookTime = cookTime;
            this.mealType = mealType;
            this.mealFrequency = mealFrequency;
            this.weekday = weekday;
        }

        @Override
        // convert the meal to a string for output
        public String toString() {
            return mealFrequency + ", " + name + ", " + cuisineType +
                    ", " + cookTime + ", " + mealType + ", " + weekday;
        }
    }

    // MessageBroker class handling communication between publishers and subscribers
    class MessageBroker {
        void notifySubscribers(String eventType, String publisherName, Meal meal) {
            // alert subscribers of meal publishings
            String mealOutput = meal.toString();
            resultBox.append("publish, " + publisherName + ", " + mealOutput + "\n");
        }

    }

    // Publisher interface representing the dietitian/nutritionist
    interface Publisher {
        void publishMealIdea(Meal meal);

        void publishDailyMeal(Meal meal);

        void publishWeeklyMeal(Meal meal, String weekday);
    }

    // Concrete implementation of a dietitian/nutritionist
    class Dietitian implements Publisher {
        String name;
        MessageBroker messageBroker;

        // constructor
        Dietitian(String name, MessageBroker messageBroker) {
            this.name = name;
            this.messageBroker = messageBroker;
        }

        @Override
        // different publish types
        public void publishMealIdea(Meal meal) {
            // Implementation to publish a meal idea
            messageBroker.notifySubscribers("Meal Idea", name, meal);
        }

        @Override
        public void publishDailyMeal(Meal meal) {
            // Implementation to publish a daily meal
            messageBroker.notifySubscribers("Daily Meal", name, meal);
        }

        @Override
        public void publishWeeklyMeal(Meal meal, String weekday) {
            // Implementation to publish a weekly meal
            messageBroker.notifySubscribers("Weekly Meal for " + weekday, name, meal);
        }
    }

    // Subscriber interface representing the customer
    interface Subscriber {
        void subscribeToMealIdeas();

        void subscribeToDailyMeals();

        void subscribeToWeeklyMeals();

        void unsubscribeFromNotifications(String frequency);
    }

    // Concrete implementation of a customer
    class Customer implements Subscriber {
        String name;

        Customer(String name) {
            this.name = name;
        }

        @Override
        // different subscription types and unsubscribe
        public void subscribeToMealIdeas() {
            // Implementation to subscribe to meal ideas
            resultBox.append("subscribe, " + name + ", mealIdea\n");
        }

        @Override
        public void subscribeToDailyMeals() {
            // Implementation to subscribe to daily meals
            resultBox.append("subscribe, " + name + ", dailyMeals\n");
        }

        @Override
        public void subscribeToWeeklyMeals() {
            // Implementation to subscribe to weekly meals
            resultBox.append("subscribe, " + name + ", weeklyMeals\n");
        }

        @Override
        public void unsubscribeFromNotifications(String frequency) {
            // Implementation to unsubscribe from notifications
            resultBox.append("unsubscribe, " + name + ", " + frequency + "\n");
        }
    }
}
